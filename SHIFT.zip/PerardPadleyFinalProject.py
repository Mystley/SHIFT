# -*- coding: utf-8 -*-
"""
Title: SHIFT

N.B.: Please refer to the User Manual for a definition of the different components
of the program.

The program is a GUI tkinter program using breezypythongui module and intended to:
    • allow the user encrypt (or mask his/ her text) by either typing directly
    in the program or encrypt a text file of his/her choice.
    • Display 2 images with alternate texts
    • Pop up a second window with information about the program when the user
    click the About button.
    • Clear the content of the encrypted text in the text field area.

Created on Sun Jul 16 23:01:00 2023
Author: Padley Perard

Ivy Tech Community College
"""


from breezypythongui import EasyFrame   #    Main window and widgets
from tkinter import PhotoImage          #    Images
from tkinter.font import Font           #    Images
import tkinter as tk                    #    Second window
N = tk.N                                #  North
S = tk.S                                #  South
E = tk.E                                #  East
W = tk.W                                #  West

# WINDOWS CREATION & WIDGET PLACEMENTS
class EncrypChoice(EasyFrame):
    """Let the user choose how he wants the encryption."""
    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "SHIFT")

        #  Label that asks the user: "How would you like to encrypt your text?"
        self.addLabel(text = "How would you like to encrypt your text?",
                      row = 1,
                      column = 0)

        #  Label that ask the user to "Type your text here".
        self.addLabel(text = "Type your text here",
                      row = 2,
                      column = 1)

        # first image block of code _________________________________

        imagePanel = self.addPanel(row = 5, column = 0) # A panel to stores the image

        # Add the alternative text to the window.
        imageLabel = imagePanel.addLabel(text = "",
                                   row = 6, column = 0,
                                   sticky = "NSEW") # Placement of the image in the program
        textLabel = imagePanel.addLabel(text = "Mask your text",
                                  row = 7, column = 0,
                                  sticky = "NSEW") # The label next to the image

        # Load the image and associate it with the alternative text.
        self.image = PhotoImage(file = "shift_logo1.gif") # The image file
        imageLabel["image"] = self.image

        # Set the font and color of the alternative text.
        font = Font(family = "Verdana", size = 20, slant = "italic")
        textLabel["font"] = font
        textLabel["foreground"] = "blue"
        # End of first image_________________________________

        #  Label that specify the constraints
        restricText = "WARNING\n Only files with (.txt) extension\n are encrypted"
        imagePanel.addLabel(restricText.ljust(10),
                      row = 5,
                      column = 0) # Placement of the constraint label

        # second image block of code_________________________________
        # A panel to stores the image
        imagePanel = self.addPanel(row = 0, column = 1) # Panel storing the image

        # Add the alternative text to the window.
        imageLabel = imagePanel.addLabel(text = "",
                                   row = 0, column = 0,
                                   sticky = "NSEW")
        textLabel = imagePanel.addLabel(text = "Join Ivy now!",
                                  row = 0, column = 1,
                                  sticky = "NSEW")

        # Load the image and associate it with the alternative text.
        self.image2 = PhotoImage(file = "IvyLogo.gif")
        imageLabel["image"] = self.image2

        # Set the font and color of the alternative text.
        font = Font(family = "Verdana", size = 20, slant = "italic")
        textLabel["font"] = font
        textLabel["foreground"] = "blue"
        # End of second image_________________________________

        #  Radio button presenting the options for the user to choose from
        self.encryptSource = self.addRadiobuttonGroup(row = 2,
                                                  column = 0,
                                                  rowspan = 2)
        self.typeHere = self.encryptSource.addRadiobutton(text = "Type here", command = self.typeHere)
        self.fromFile = self.encryptSource.addRadiobutton(text = "From a file", command = self.fromFile)
        self.encryptSource.setSelectedButton(self.fromFile) #  Select this button by default
        #  Creation of text field  #  Default disable of text field
        self.inputField = self.addTextField(text = "test", row = 3, column = 1,columnspan=1,rowspan=1,width=60,sticky=N+W, state= "disabled")

        # Create the panel for the buttons
        buttonPanel = self.addPanel(row = 4, column = 1,
                                  background = "gray")

        #  Click buttons to encrypt, clear, or new encryption
        self.encryptButton = buttonPanel.addButton("Encrypt", 4, 1,columnspan=1,rowspan=1, command = self.encrypOutput)
        self.encryptButton["state"] = "disabled"
        buttonPanel.addButton("Clear", 4, 2,columnspan=1,rowspan=1, command = self.clearContent)
        buttonPanel.addButton("About", 4, 3,columnspan=1,rowspan=1, command = openNewWindow)
        self.selectFile = self.addButton(text = "Select file", row = 4, column = 0,
                       command = self.openFile)

        #  Output field of the encrypted text
        self.outputField = self.addTextArea("", 5, 1, rowspan=1, columnspan=1,width=80, height=20)


#  EVENTS
    # What should happen

    def openFile(self): #  when user click Select file button and open a text file
        """Pops up an open file dialog, and if a file is
        selected, displays its text in the text area and
        its pathname in the title bar."""
        fList = [("Text files", "*.txt")]
        fileName = tk.filedialog.askopenfilename(parent = self,
                                                      filetypes = fList)
        if fileName != "":
            file = open(fileName, 'r')
            txt = file.read()
            file.close()
            self.inputField.setText(fileName) # insert name of file opened

            #  key
            x = "bcdfghjklmnpqrstvwxzAEIOUYaeiouyBCDFGHJKLMNPQRSTVWXZ"
            y = "zxwvtsrqpnmlkjhgfdcbYUOIEAyuoieaZXWVTSRQPNMLKJHGFDCB"

            mytable = str.maketrans(x, y) # stores the replacement of each letter
            encrypText = txt.translate(mytable) # goes over the words in the file and apply the replacement of the letters
            self.outputField.setText(encrypText) #  display the encrypted text in the text area.

    def encrypOutput(self): #  when Encrypt button is clicked
        txt = self.inputField.getText()

        #  key
        x = "bcdfghjklmnpqrstvwxzAEIOUYaeiouyBCDFGHJKLMNPQRSTVWXZ"
        y = "zxwvtsrqpnmlkjhgfdcbYUOIEAyuoieaZXWVTSRQPNMLKJHGFDCB"

        mytable = str.maketrans(x, y) # stores the replacement of each letter
        encrypText = txt.translate(mytable) # goes over the words in the file and apply the replacement of the letters
        self.outputField.setText(encrypText) #  display the encrypted text in the text area.

    def clearContent(self): # when the "clear" button is clicked
        """"Clear the content of the text area (the encrypted text)"""
        self.outputField.setText("") # replace all the content in the text area by an empty string

    def fromFile(self): #  when "from a file" radio button is clicked
        """Disable the select button when 'From a file' radio button is selected"""
        self.selectFile["state"] = "normal"
        self.inputField["state"] = "disabled"

    def typeHere(self): #  when "type here" radio button is clicked
        """Disable the select button when 'type Here' radion button is selected"""
        self.selectFile["state"] = "disabled"
        self.inputField["state"] = "normal"
        self.encryptButton["state"] = "normal"


#  SECOND WINDOW DESCRIBING THE APP.
def openNewWindow(): #  Function that will open a new window

    newWindow = tk.Toplevel()

	# sets the title of the window
    newWindow.title("About")

	# sets the geometry of toplevel
    newWindow.geometry("200x200")

	# A Label widget to show in toplevel
    text = "SHIFT\n Developer: Padley Perard\n Version: 1.0\n"
    tk.Label(newWindow,
		text=text).pack()

def main():
    """Instantiate and pop up the window."""
    EncrypChoice().mainloop()

if __name__ == "__main__":
    main()
